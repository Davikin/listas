package com.example.listas;

public class Vehiculo {
    protected int velocidad;
    protected String fuenteEnergia;

    protected void Cargar(){

    }


}
