package com.example.listas;

public class Coche extends Vehiculo {

    void CargarGasolina(){

        Cargar();
        fuenteEnergia = "Gasolina";
        velocidad = 60;

    }

}
