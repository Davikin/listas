package com.example.listas;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

//MyAdapter es hijo de BaseAdapter
public class MyAdapter extends BaseAdapter {
    Context contexto;
    List<Pelicula> listaPeliculas;
    int layout;

    //Constructor
    public MyAdapter(Context _contexto, List<Pelicula> _listaPeliculas, int _layout){
        contexto = _contexto;
        listaPeliculas = _listaPeliculas;
        layout = _layout;
    }

    @Override
    public int getCount() {
        return listaPeliculas.size();
    }

    @Override
    public Object getItem(int i) {
        return listaPeliculas.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        LayoutInflater inflater = LayoutInflater.from(this.contexto); //Se crea un inflater para nuestra pantalla
        Pelicula pelicula = (Pelicula) getItem(i);

        //Infla la list view con el elemento que le pidamos
        //Que en este caso es pelicula_item
        view = inflater.inflate(R.layout.pelicula_item, null);

        TextView tituloTextView = view.findViewById(R.id.titulo_pelicula);
        TextView clasificacionTextView = view.findViewById(R.id.clasificacion_pelicula);
        TextView duracionTextView = view.findViewById(R.id.duracion_pelicula);
        ImageView imagenPelicula = view.findViewById(R.id.imagen_pelicula);

        tituloTextView.setText(pelicula.titulo);
        clasificacionTextView.setText(pelicula.clasificacion);
        duracionTextView.setText(pelicula.duracion);
        imagenPelicula.setImageResource(pelicula.imagen);

        return view;
    }
}
