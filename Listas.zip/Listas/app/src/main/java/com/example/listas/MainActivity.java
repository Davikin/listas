package com.example.listas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //Clase generica
    //MiClaseGenerica<ClaseHija>

    //Lista de strings
    //List<String> peliculas = new ArrayList<>();
    List<Pelicula> peliculas = new ArrayList<>();

    ListView miListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        miListView = findViewById(R.id.mi_list_view);

        /*
        peliculas.add("Endgame");
        peliculas.add("El Señor de los Anillos");
        peliculas.add("Big Fish");
        peliculas.add("Silencio de los Inocentes");
        peliculas.add("The Shining");
        peliculas.add("Ralph el Demoledor");
        peliculas.add("El Padrino");
        peliculas.add("Tiburon");
        peliculas.add("Fight Club");
        peliculas.add("Blade Runner 2049");
        */

        peliculas.add(new Pelicula("Endgame", R.drawable.avengers_endgame, "180 min", "B"));
        peliculas.add(new Pelicula("El Señor de los Anillos", R.drawable.senor_de_los_anillos, "150 min", "B"));
        peliculas.add(new Pelicula("Big Fish", R.drawable.big_fish, "100 min", "A"));

        miListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String peliculaEscogida = peliculas.get(i).titulo;
                Toast.makeText(adapterView.getContext(), "Hoy quiero ver la pelicula #"+i
                                                                +", que es: "+peliculaEscogida, Toast.LENGTH_SHORT).show();
            }
        });

        //ArrayAdapter de strings (tambien es una clase generica)
        //Ya no lo voy a usar por el momento
        //ArrayAdapter<String> miAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, peliculas);
        MyAdapter myAdapter = new MyAdapter(this, peliculas, R.layout.pelicula_item);

        //Le digo a mi list view que utilice miAdapter para acomodar sus datos
        //miListView.setAdapter(miAdapter); //Ya no voy a usar miAdapter
        miListView.setAdapter(myAdapter);
    }
}
