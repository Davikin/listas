package com.example.listas;

public class Pelicula {
    String titulo;
    int imagen;
    String duracion;
    String clasificacion;

    //Constructor
    public Pelicula(String _titulo, int _imagen, String _duracion, String _clasificacion){
        titulo = _titulo;
        imagen = _imagen;
        duracion = _duracion;
        clasificacion = _clasificacion;
    }
}
